
def credit(income, expenses):
    # Если ЛЮБАЯ из сумм (доходы или расходы) >= 100к → проверяем условия
    if income >= 100_000 or expenses >= 100_000:
        # Проверка: расходы > доходов ИЛИ разница <= 15%
        if expenses > income:
            return True
        difference = (income - expenses) / income
        return difference <= 0.15  # Разница 15% или меньше → True
    # Иначе (если обе суммы < 100к) → False
    return False

def get_proposed_product(data):
    income = data.get('Income')
    expenses = data.get("Expenses")
    if data.get("client_data"):
        income = data.get('client_data').get('Income')
        expenses = data.get('client_data').get('Expenses')

    is_credit = credit(income, expenses)

    products = data.get('products')
    products_client = [product['name'] for product in products]

    if "Кредит" in products_client:
        "Залог имущества"
    elif is_credit and not "Кредитование" in products_client:
        return "Кредитование"
    elif "Инвестиции" in products_client and not "Кредитная карта" in products_client:
        return "Кредитная карта"
    elif "Вклад" in products_client and not "Инвестиции" in products_client:
        return "Инвестиции"
    elif "Дебетовая карта" in products_client and not "Вклад" in products_client:
        return "Вклад"
    else:
        if not "Дебетовая карта" in products_client:
            return "Дебетовая карта"
        else:
            return "Нет подходящих продуктов"