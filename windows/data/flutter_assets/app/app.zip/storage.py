import configparser
from typing import Literal

ThemeMode = Literal["system", "light", "dark"]
Language = Literal["ru", "en"]

config = configparser.ConfigParser()
config.read('config.ini')

def get_theme():
    return config['app']['theme_mode']

def get_lang():
    return config['app']['lang']


def change_theme_mode(new_mode: ThemeMode):
    """Изменяет тему приложения (system/light/dark)"""
    if 'app' not in config:
        config['app'] = {}  # Создаем секцию если её нет

    config['app']['theme_mode'] = new_mode

    with open('config.ini', 'w') as configfile:
        config.write(configfile)


def change_language(new_lang: Language):
    """Изменяет язык приложения (ru/en)"""

    if 'app' not in config:
        config['app'] = {}  # Создаем секцию если её нет

    config['app']['lang'] = new_lang

    with open('config.ini', 'w') as configfile:
        config.write(configfile)