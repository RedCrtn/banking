import flet as ft

from api import ApiClient
from language import translate
from storage import get_lang


class AdminPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page

        self.lang = get_lang()
        self.api = ApiClient()

        self.padding = 0
        self.expand = True
        self.user_data = self.page.session.get("user_data")
        self.selected_products = []

        self.horizontal_alignment = ft.CrossAxisAlignment.CENTER

        self.controls = [
            ft.Container(
                ft.Column([
                    ft.FilledButton(
                        translate("Создать нового пользователя", self.lang),
                        on_click=self.dlg_create_user,
                        style=ft.ButtonStyle(
                            shape=ft.RoundedRectangleBorder(5),
                            color="#1f1f1f",
                            bgcolor=ft.Colors.AMBER_ACCENT_400
                        )
                    ),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True),
                expand=True,
                padding=ft.padding.only(top=70),
                alignment=ft.alignment.center
            )
        ]
        self.visible_role = self.user_data.get('role') == "admin"
        self.roles = [
            ft.dropdownm2.Option(text=translate("Клиент", self.lang), key="client"),
            ft.dropdownm2.Option(text=translate("Менеджер", self.lang), key="manager", visible=self.visible_role),
            ft.dropdownm2.Option(text=translate("Руководитель", self.lang), key="specialist", visible=self.visible_role),
            ft.dropdownm2.Option(text=translate("Администратор", self.lang), key="admin", visible=self.visible_role),
        ]

        self.products_controls = [
            ft.Checkbox(label=product['name'], data=product['id'], on_change=self.on_select_product, width=145) for product in self.api.get_all_products()
        ]

        self.ref_fio = ft.Ref[ft.CupertinoTextField]()
        self.ref_number_phone = ft.Ref[ft.CupertinoTextField]()
        self.ref_email = ft.Ref[ft.CupertinoTextField]()
        self.ref_passport = ft.Ref[ft.CupertinoTextField]()
        self.ref_login = ft.Ref[ft.CupertinoTextField]()
        self.ref_password = ft.Ref[ft.CupertinoTextField]()
        self.ref_role = ft.Ref[ft.DropdownM2]()

    def dlg_create_user(self, e):
        dlg = ft.AlertDialog(
            title=ft.Text(translate("Новый пользователь", self.lang), weight=ft.FontWeight.BOLD, size=20),
            content=ft.Column([
                ft.CupertinoTextField(
                    translate("ФИО", self.lang),
                    ref=self.ref_fio
                ),
                ft.CupertinoTextField(
                    translate("Номер телефона", self.lang),
                    ref=self.ref_number_phone
                ),
                ft.CupertinoTextField(
                    translate("E-mail", self.lang),
                    ref=self.ref_email
                ),
                ft.CupertinoTextField(
                    translate("Паспорт", self.lang),
                    ref=self.ref_passport
                ),
                ft.CupertinoTextField(
                    translate("Логин", self.lang),
                    ref=self.ref_login
                ),
                ft.CupertinoTextField(
                    translate("Пароль", self.lang),
                    ref=self.ref_password
                ),
                ft.DropdownM2(
                    value="client",
                    height=40,
                    padding=-8,
                    width=110,
                    ref=self.ref_role,
                    options=self.roles,
                ),
                ft.Container(
                    ft.Row(
                        self.products_controls,
                        expand=True,
                        wrap=True,
                        spacing=0,
                    ),
                    height=110
                ),
                ft.FilledButton(
                    translate("Создать", self.lang),
                    bgcolor="#fedd2c",
                    color="#000000",
                    on_click=self.create_user,
                    width=180,
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(4)
                    )
                )
            ], height=470, horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True, width=300),
            shape=ft.RoundedRectangleBorder(6)
        )
        self.page.open(dlg)

    def create_user(self, e):
        fields = [
            self.ref_fio.current,
            self.ref_role.current,
            self.ref_number_phone.current,
            self.ref_email.current,
            self.ref_passport.current,
            self.ref_login.current,
            self.ref_password.current,
        ]
        user_data = {
                "fio": self.ref_fio.current.value,
                "role": self.ref_role.current.value,
                "phone": self.ref_number_phone.current.value,
                "email": self.ref_email.current.value,
                "passport": self.ref_passport.current.value,
                "login": self.ref_login.current.value,
                "password": self.ref_password.current.value,
                "products": self.selected_products
            }
        response = self.api.create_user(
            user_data=user_data
        )
        self.selected_products.clear()
        if response:
            self.page.open(
                ft.SnackBar(
                    ft.Text(
                        "Новый пользователь успешно добавлен"
                    )
                )
            )
            for field in fields:
                field.value = ""
                field.update()
            for field in self.products_controls:
                field.value = False
                field.update()

    def on_select_product(self, e):
        if e.control.data in self.selected_products:
            self.selected_products.remove(e.control.data)
        else:
            self.selected_products.append(e.control.data)