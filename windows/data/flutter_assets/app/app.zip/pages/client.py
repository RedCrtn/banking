import flet as ft

from api import ApiClient
from create_doc import create_doc_not_signet, signet_document
from language import translate
from proposed_product import get_proposed_product
from storage import get_lang


class ClientPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page

        self.lang = get_lang()
        self.api = ApiClient()

        self.padding = 0
        self.expand = True
        self.client_data = self.page.session.get("client_selected_data")
        
        self.user_data = self.page.session.get("user_data")
        self.is_report = self.api.get_report(self.client_data.get('id'))

        if self.is_report:
            if self.is_report.get('doc'):
                self.is_signed = self.is_report.get('doc')['is_signed']
            else:
                self.is_signed = False
        else:
            self.is_signed = False

        self.controls = [
            ft.Container(
                ft.Column([
                    ft.Row([
                        ft.FilledButton(
                            translate("Назад", self.lang),
                            on_click=lambda e: self.page.go(f'/clients'),
                            bgcolor="#7b98fe",
                            color="#ebebeb",
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(4)
                            )
                        )
                    ]),
                    ft.Row([
                        ft.Container(
                            ft.Icon(ft.CupertinoIcons.PERSON_ALT_CIRCLE, size=45, color="#5380f2"),
                            shape=ft.BoxShape.CIRCLE,
                        ),
                        ft.Text(
                            self.client_data.get('fio'),
                            text_align=ft.TextAlign.LEFT,
                        )
                    ]),
                    ft.Row([
                        ft.Container(
                            ft.Icon(ft.CupertinoIcons.PHONE_CIRCLE_FILL, size=45, color="#5380f2"),
                            shape=ft.BoxShape.CIRCLE,
                        ),
                        ft.Text(
                            self.client_data.get('phone'),
                            text_align=ft.TextAlign.LEFT,
                        )
                    ]),
                    ft.Row([
                        ft.Container(
                            ft.Icon(ft.Icons.EMAIL, size=45, color="#5380f2"),
                            shape=ft.BoxShape.CIRCLE,
                        ),
                        ft.Text(
                            self.client_data.get('email'),
                            text_align=ft.TextAlign.LEFT,
                        )
                    ]),
                    ft.Row([
                        ft.Container(
                            ft.Icon(ft.Icons.DOCUMENT_SCANNER, size=45, color="#5380f2"),
                            shape=ft.BoxShape.CIRCLE,
                        ),
                        ft.Text(
                            self.client_data.get('passport'),
                            text_align=ft.TextAlign.LEFT,
                        )
                    ]),
                    ft.Row([
                        ft.Container(
                            ft.Icon(ft.Icons.CREDIT_CARD, size=45, color="#5380f2"),
                            shape=ft.BoxShape.CIRCLE,
                        ),
                        ft.Text(
                            f"{translate("Предлагаемый продукт", self.lang)}: {get_proposed_product(self.client_data)}",
                            text_align=ft.TextAlign.LEFT,
                        )
                    ]),
                    ft.Row([
                        ft.FilledButton(
                            translate("Сформировать отчет", self.lang),
                            on_click=self.create_report,
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(5),
                                color="#1f1f1f",
                                bgcolor=ft.Colors.AMBER_ACCENT_400
                            )
                        ),
                        ft.FilledButton(
                            translate("Оформить договор", self.lang),
                            visible=True if self.user_data.get('role') in ["specialist", "admin"] and self.is_report else False,
                            on_click=self.create_document,
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(5),
                                color="#1f1f1f",
                                bgcolor=ft.Colors.AMBER_ACCENT_400
                            )
                        ),
                        ft.FilledButton(
                            translate("Подписать договор", self.lang),
                            visible=True if self.user_data.get('role') in ["specialist",
                                                                           "admin"] and self.is_report else False,
                            on_click=self.podpisat_document,
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(5),
                                color="#1f1f1f",
                                bgcolor=ft.Colors.AMBER_ACCENT_400
                            )
                        )
                    ], spacing=30),
                ], spacing=15, alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.START, width=500),
                expand=True,
                alignment=ft.alignment.center
            )
        ]

    def create_report(self, e):
        report = self.api.create_report(self.client_data.get('id'))
        self.page.session.set("report_data", report)
        self.page.go('/report')

    def create_document(self, e):
        report = self.api.get_report(self.client_data.get('id'))
        create_doc_not_signet(self.client_data)
        self.api.create_document(
            {
                "client_id": self.client_data.get('id'),
                "report_id": report.get("id")
            }
        )
        self.page.open(
            ft.SnackBar(
                ft.Text(
                    "Договор составлен, ожидаем подписи руководителя. Документ на рабочем столе"
                )
            )
        )

    def podpisat_document(self, e):
        report = self.api.get_report(self.client_data.get('id'))
        signet_document(self.client_data)
        self.api.create_document(
            {
                "client_id": self.client_data.get('id'),
                "report_id": report.get("id"),
                'is_signed': True
            }
        )
        self.page.open(
            ft.SnackBar(
                ft.Text(
                    "Договор подписан электронной подписью. Документ на рабочем столе"
                )
            )
        )