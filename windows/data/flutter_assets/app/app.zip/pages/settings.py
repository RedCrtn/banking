import flet as ft

from api import ApiClient
from language import translate
from storage import get_theme, change_theme_mode, get_lang, change_language
from themes import light_theme, dark_theme


class SettingsPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page

        self.padding = 0
        self.expand = True
        self.api = ApiClient()
        self.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        self.vertical_alignment = ft.MainAxisAlignment.CENTER

        self.ref_old_password_field = ft.Ref[ft.CupertinoTextField]()
        self.ref_new_password_field = ft.Ref[ft.CupertinoTextField]()

        self.lang = get_lang()

        self.theme_options = [
                                ft.dropdownm2.Option(text=translate("Системная", self.lang), key="system"),
                                ft.dropdownm2.Option(text=translate("Тёмная", self.lang), key="dark"),
                                ft.dropdownm2.Option(text=translate("Светлая", self.lang), key="light"),
                            ]

        self.lang_options = [
                                ft.dropdownm2.Option(text="Русский", key="ru"),
                                ft.dropdownm2.Option(text="English", key="en"),
                            ]

        self.dlg_change_password = ft.AlertDialog(
            title=ft.Text(translate("Смена пароля", self.lang), weight=ft.FontWeight.BOLD, size=20),
            content=ft.Column([
                ft.CupertinoTextField(
                    translate("Старый пароль", self.lang),
                    ref=self.ref_old_password_field
                ),
                ft.CupertinoTextField(
                    translate("Новый пароль", self.lang),
                    ref=self.ref_new_password_field
                ),
                ft.FilledButton(
                    translate("Сменить пароль", self.lang),
                    bgcolor="#fedd2c",
                    color="#000000",
                    on_click=self.change_password,
                    width=180,
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(4)
                    )
                )
            ], height=120, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            shape=ft.RoundedRectangleBorder(6)
        )

        self.controls = [
            ft.Container(
                ft.Column([
                    ft.Row([
                        ft.Text(translate("Язык", self.lang), weight=ft.FontWeight.BOLD),
                        ft.DropdownM2(
                            value=get_lang(),
                            on_change=lambda e: change_language(e.data),
                            height=40,
                            padding=-8,
                            width=110,
                            options=self.lang_options,
                        )
                    ]),
                    ft.Row([
                        ft.Text(translate("Тема", self.lang), weight=ft.FontWeight.BOLD),
                        ft.DropdownM2(
                            value=get_theme(),
                            height=40,
                            padding=-8,
                            on_change=self.theme_change,
                            width=110,
                            options=self.theme_options,
                        )
                    ]),
                    ft.Row([
                        ft.Text(translate("Пароль", self.lang), weight=ft.FontWeight.BOLD),
                        ft.FilledButton(
                            translate("Сменить пароль", self.lang),
                            height=30,
                            on_click=self.change_password_dialog,
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(4)
                            )
                        )
                    ]),
                ], alignment=ft.MainAxisAlignment.CENTER),
                alignment=ft.alignment.center,
                width=230,
                expand=False
            )
        ]

    def change_password_dialog(self, e):
        self.page.open(self.dlg_change_password)

    def change_password(self, e):
        user = self.page.session.get("user_data")
        result = self.api.change_password(
            login=user.get("login"),
            current_password=self.ref_old_password_field.current.value,
            new_password=self.ref_new_password_field.current.value
        )
        if not result:
            self.page.open(
                ft.SnackBar(
                    ft.Text(
                        "Пароль не верный"
                    )
                )
            )
        else:
            self.page.open(
                ft.SnackBar(
                    ft.Text(
                        "Пароль успешно был изменен"
                    )
                )
            )
            self.page.close(self.dlg_change_password)

    def theme_change(self, e):
        self.page.theme_mode = e.data
        if e.data == "light":
            self.page.theme = light_theme
        elif e.data == "dark":
            self.page.theme = dark_theme
        self.page.update()
        change_theme_mode(e.data)