import flet as ft
from pydantic import AnyWebsocketUrl

from api import ApiClient
from language import translate
from pages.products import ProductCard
from proposed_product import get_proposed_product
from storage import get_lang


class ReportPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page

        self.lang = get_lang()
        self.api = ApiClient()

        self.padding = 0
        self.expand = True
        self.report_data = self.page.session.get("report_data")
        self.horizontal_alignment = ft.CrossAxisAlignment.CENTER

        self.controls = [
            ft.Container(
                ft.Column([
                    ft.Row([
                        ft.Container(
                            ft.Text(f"{translate("ИТОГО ДОХОДОВ", self.lang)}\n", size=16, spans=[
                                ft.TextSpan(
                                    f"{self.report_data.get("Income"):,}".replace(',', ' '),
                                    style=ft.TextStyle(weight=ft.FontWeight.BOLD)
                                )
                            ]),
                            bgcolor="green"
                        ),
                        ft.Container(
                            ft.Text(f"{translate("ИТОГО РАСХОДОВ", self.lang)}\n", size=16, spans=[
                                ft.TextSpan(
                                    f"{self.report_data.get("Expenses"):,}".replace(',', ' '),
                                    style=ft.TextStyle(weight=ft.FontWeight.BOLD)
                                )
                            ]),
                            bgcolor="blue"
                        )
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Column([
                        ft.Container(margin=20),
                        ft.Text(translate("Продукты клиента", self.lang), size=20),
                        *[
                            ProductCard(
                                self.page,
                                is_client=self.del_product,
                                product_data=product
                            ) for product in self.report_data.get("products")
                        ],
                        ft.Text(f"{translate("Предлагаемый продукт", self.lang)}: {get_proposed_product(self.report_data)}", size=20),
                        ft.FilledButton(
                            translate(translate("Предложить продукт", self.lang), self.lang),
                            on_click=lambda e: self.proposed_product(get_proposed_product(self.report_data)),
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(5),
                                color="#1f1f1f",
                                bgcolor=ft.Colors.AMBER_ACCENT_400
                            )
                        )
                    ], width=400, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, expand=True),
                expand=True,
                padding=ft.padding.only(top=70, right=55),
                alignment=ft.alignment.center
            )
        ]

    def proposed_product(self, product_name):
        products = self.api.get_all_products()
        for product in products:
            if product['name'] == product_name:
                self.api.add_client_product({
                    "client_id": self.report_data.get('client_id') if self.report_data.get('id') is None else self.report_data.get('id'),
                    "product_id": product['id']
                })
        self.page.go('/reports')


    def del_product(self, product_id):
        self.api.del_client_product({
            "client_id": self.report_data.get('client_id') if self.report_data.get(
                'id') is None else self.report_data.get('id'),
            "product_id": product_id
        })
        self.page.go('/reports')