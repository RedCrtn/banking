from typing import Optional

import flet as ft

from api import ApiClient
from language import translate
from storage import get_lang


class ProductCard(ft.Card):
    def __init__(
            self,
            page,
            product_data: dict | str,
            is_client: Optional[callable] = None
    ):
        super().__init__()

        self.lang = get_lang()

        self.product_data = product_data
        self.page = page
        self.border_radius = 3
        self.is_client = is_client

        if isinstance(product_data, str):
            self.product_data = {
                "name": self.product_data
            }

        self.content = ft.Container(
            ft.Row([
                ft.Text(self.product_data.get("name")),
                ft.Row([
                    ft.FilledButton(
                        translate("Подробнее", self.lang),
                        on_click=self.open_more_info_product,
                        visible=True if self.product_data.get("description") else False,
                        style=ft.ButtonStyle(
                            shape=ft.RoundedRectangleBorder(4)
                        )
                    ),
                    ft.IconButton(icon=ft.Icons.DELETE, icon_color="red", on_click=lambda _: self.dlg_delete_product(self.product_data.get('id')), visible=True if self.is_client else False)
                ])
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN), padding=10)

    def open_more_info_product(self, e):
        dlg = ft.AlertDialog(
            title=ft.Text(self.product_data.get("name"), weight=ft.FontWeight.BOLD, size=20),
            content=ft.Text(self.product_data.get("description"), size=15),
            shape=ft.RoundedRectangleBorder(6)
        )
        self.page.open(dlg)

    def dlg_delete_product(self, product_id):
        dlg = ft.AlertDialog(
            title=ft.Text("Удалить этот продукт у данного клиента?", weight=ft.FontWeight.BOLD, size=20),
            actions=[
                ft.FilledButton("Да, удалить", on_click=lambda e: (self.page.close(dlg), self.is_client(product_id))),
                ft.OutlinedButton("Отмена", style=ft.ButtonStyle(color="#e3e3e3"), on_click=lambda e: self.page.close(dlg)),
            ],
            shape=ft.RoundedRectangleBorder(6)
        )
        self.page.open(dlg)

class ProductsPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page

        self.padding = 0
        self.expand = True
        self.api = ApiClient()


        self.get_products = self.api.get_all_products()
        self.products = [
            ProductCard(
                self.page,
                product_data=product
            ) for product in self.get_products
        ]

        self.controls = [
            ft.Container(
                ft.ListView(
                    self.products,
                    expand=True,
                    spacing=10,
                    width=500,
                    height=500
                ),
                alignment=ft.alignment.center,
                expand=True
            )
        ]
