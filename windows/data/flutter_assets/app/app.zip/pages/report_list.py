import flet as ft

from api import ApiClient
from language import translate
from pages.products import ProductCard
from storage import get_lang


class ReportCard(ft.Card):
    def __init__(
            self,
            page,
            report_data: dict
    ):
        super().__init__()

        self.lang = get_lang()

        self.report_data = report_data
        self.page = page
        self.border_radius = 3
        self.padding = 5
        self.api = ApiClient()

        self.content = ft.Container(
            ft.Row([
                ft.Text(f"Отчет: {self.report_data.get("fio")}"),
                ft.Row([
                    ft.FilledButton(
                        translate("Открыть", self.lang),
                        on_click=self.open_client_page,
                        style=ft.ButtonStyle(
                            shape=ft.RoundedRectangleBorder(4)
                        )
                    ),
                    ft.IconButton(icon=ft.Icons.DELETE, icon_color="red",
                                  on_click=lambda _: self.dlg_delete_report(self.report_data.get("client_id")))
                ])
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN), padding=5)

    def dlg_delete_report(self, client_id):
        dlg = ft.AlertDialog(
            title=ft.Text("Удалить этот отчет данного клиента?", weight=ft.FontWeight.BOLD, size=20),
            actions=[
                ft.FilledButton("Да, удалить", on_click=lambda e: (self.page.close(dlg), self.remove_report(client_id))),
                ft.OutlinedButton("Отмена", style=ft.ButtonStyle(color="#e3e3e3"), on_click=lambda e: self.page.close(dlg)),
            ],
            shape=ft.RoundedRectangleBorder(6)
        )
        self.page.open(dlg)

    def remove_report(self, client_id):
        self.api.remove_report(client_id)
        self.page.go("/account")
        self.page.go("/reports")

    def open_client_page(self, e):
        self.page.session.set("report_data", self.report_data)
        self.page.go(f"/report")

class ReportListPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page

        self.lang = get_lang()

        self.padding = 0
        self.expand = True
        self.report_data = self.page.session.get("report_data")
        self.api = ApiClient()

        self.horizontal_alignment = ft.CrossAxisAlignment.CENTER

        self.get_reports = self.api.get_reports()

        self.reports = [
            ReportCard(
                self.page,
                client,
            ) for client in self.get_reports
        ]

        self.controls = [
            ft.Container(
                ft.ListView(
                    self.reports,
                    expand=True,
                    spacing=0,
                    width=400,
                    height=500
                ),
                alignment=ft.alignment.center,
                expand=True
            )
        ]