import json

import flet as ft

from api import ApiClient
from language import translate
from storage import get_lang
from themes import dark_theme


class ClientCard(ft.Card):
    def __init__(
            self,
            page,
            user_data: dict
    ):
        super().__init__()

        self.lang = get_lang()

        self.user_data = user_data
        self.page = page
        self.border_radius = 3
        self.padding = 5

        self.content = ft.Container(
            ft.Row([
                ft.Text(self.user_data.get("fio")),
                ft.FilledButton(
                    translate("Профиль", self.lang),
                    on_click=self.open_client_page,
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(4)
                    )
                )
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN), padding=5)

    def open_client_page(self, e):
        self.page.session.set("client_selected_data", self.user_data)
        self.page.go(f"/client")

class ClientsPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page

        self.padding = 0
        self.expand = True

        self.api = ApiClient()

        self.get_clients = self.api.get_clients()
        print(self.get_clients)

        self.clients = [
            ClientCard(
                self.page,
                client,
            ) for client in self.get_clients
        ]

        self.controls = [
            ft.Container(
                ft.ListView(
                    self.clients,
                    expand=True,
                    spacing=0,
                    width=400,
                    height=500
                ),
                alignment=ft.alignment.center,
                expand=True
            )
        ]
