import flet as ft

from api import ApiClient
from language import translate
from storage import get_lang


class AuthPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page


        self.api = ApiClient()
        self.lang = get_lang()
        self.padding = 0
        self.expand = True
        self.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        self.vertical_alignment = ft.MainAxisAlignment.CENTER

        self.ref_login_field = ft.Ref[ft.CupertinoTextField]()
        self.ref_password_field = ft.Ref[ft.CupertinoTextField]()

        self.menubar = ft.MenuBar(
        style=ft.MenuStyle(
            alignment=ft.alignment.top_left,
            mouse_cursor={
                ft.ControlState.HOVERED: ft.MouseCursor.WAIT,
                ft.ControlState.DEFAULT: ft.MouseCursor.ZOOM_OUT,
            },
        ),
        controls=[
            ft.MenuItemButton(
                content=ft.Text(translate("Клиенты", self.lang)),
                on_click=lambda e: page.go('/clients')
            ),
            ft.MenuItemButton(
                content=ft.Text(translate("Продукты", self.lang)),
                on_click=lambda e: page.go('/products')
            ),
            ft.MenuItemButton(
                content=ft.Text(translate("Отчетность", self.lang)),
                on_click=lambda e: page.go('/reports')
            ),
            ft.MenuItemButton(
                content=ft.Text(translate("Настройки", self.lang)),
                on_click=lambda e: page.go('/settings')
            ),
            ft.MenuItemButton(
                content=ft.Row([ft.Text(translate("Личный кабинет", self.lang)), ft.Icon(name=ft.CupertinoIcons.PERSON_ALT_CIRCLE)]),
                on_click=lambda e: page.go('/account')
            )
        ]
    )

        self.controls = [
                ft.Card(
                    ft.Container(
                        ft.Column([
                            ft.Text(translate("Вход", self.lang), weight=ft.FontWeight.BOLD, size=35),
                            ft.CupertinoTextField(
                                translate("Логин", self.lang),
                                ref=self.ref_login_field
                            ),
                            ft.CupertinoTextField(
                                translate("Пароль", self.lang),
                                ref=self.ref_password_field
                            ),
                            ft.FilledButton(
                                translate("Продолжить", self.lang),
                                on_click=self.auth,
                                bgcolor="#fedd2c",
                                color="#000000",
                                width=180,
                                style=ft.ButtonStyle(
                                    shape=ft.RoundedRectangleBorder(4)
                                )
                            )
                        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                        border_radius=6,
                        width=400,
                        padding=10
                    ),
                )
        ]

    def auth(self, e):
        auth_data = self.api.authenticate(self.ref_login_field.current.value, self.ref_password_field.current.value)
        if not auth_data:
            self.page.open(
                ft.SnackBar(
                    ft.Text(
                        "Неверный логин или пароль"
                    )
                )
            )
        else:
            self.page.session.set("user_data", auth_data)
            self.page.overlay.append(
                ft.Row([
                    ft.Container(
                        ft.MenuBar(
                            style=ft.MenuStyle(
                                alignment=ft.alignment.top_left,
                                mouse_cursor={
                                    ft.ControlState.HOVERED: ft.MouseCursor.WAIT,
                                    ft.ControlState.DEFAULT: ft.MouseCursor.ZOOM_OUT,
                                },
                            ),
                            controls=[
                                ft.MenuItemButton(
                                    content=ft.Text(translate("Управление", self.lang)),
                                    on_click=lambda e, page=self.page: page.go('/admin'),
                                    visible=True if auth_data.get("role") != "client" else False
                                ),
                                ft.MenuItemButton(
                                    content=ft.Text(translate("Клиенты", self.lang)),
                                    on_click=lambda e, page=self.page: page.go('/clients'),
                                    visible=True if auth_data.get("role") != "client" else False
                                ),
                                ft.MenuItemButton(
                                    content=ft.Text(translate("Продукты", self.lang)),
                                    on_click=lambda e, page=self.page: page.go('/products'),
                                ),
                                ft.MenuItemButton(
                                    content=ft.Text(translate("Отчетность", self.lang)),
                                    on_click=lambda e, page=self.page: page.go('/reports'),
                                    visible=True if auth_data.get("role") != "client" else False
                                ),
                                ft.MenuItemButton(
                                    content=ft.Text(translate("Настройки", self.lang)),
                                    on_click=lambda e, page=self.page: page.go('/settings'),
                                ),
                                ft.MenuItemButton(
                                    content=ft.Row([ft.Text(translate("Личный кабинет", self.lang)),
                                                    ft.Icon(name=ft.CupertinoIcons.PERSON_ALT_CIRCLE)]),
                                    on_click=lambda e, page=self.page: page.go('/account'),
                                )
                            ]
                        ),
                        margin=10
                    )
                ], expand=True, alignment=ft.MainAxisAlignment.CENTER)
            )
            self.page.go("/account")

