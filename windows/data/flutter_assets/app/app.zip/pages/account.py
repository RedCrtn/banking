import flet as ft

from language import translate
from storage import get_lang

roles = {
    "admin": "Администратор",
    "manager": "Менеджера по работе с клиентами",
    "specialist": "Специалиста по продуктам",
}


class AccountPage(ft.View):
    def __init__(self, page):
        super().__init__()
        self.page = page

        self.padding = 0
        self.expand = True

        self.user_data: dict = self.page.session.get('user_data')
        self.lang = get_lang()

        self.controls = [
            ft.Container(
                ft.Column([
                    ft.Row([
                        ft.Container(
                            height=32,
                            width=32,
                            bgcolor="#d7d5d1",
                            shape=ft.BoxShape.CIRCLE
                        ),
                        ft.Text(
                            f"{self.user_data.get('fio', "").replace(" ", "\n")}",
                            text_align=ft.TextAlign.LEFT,
                            weight=ft.FontWeight.BOLD
                        )
                    ]),
                    ft.Text(
                        f"{translate("Телефон", self.lang)}\n",
                        weight=ft.FontWeight.BOLD,
                        spans=[
                            ft.TextSpan(
                                self.user_data.get('phone', "Не указано"),
                                style=ft.TextStyle(
                                    weight=ft.FontWeight.NORMAL,
                                    color=ft.Colors.GREY_400
                                )
                            )
                        ]
                    ),
                    ft.Text(
                        "E-mail\n",
                        weight=ft.FontWeight.BOLD,
                        spans=[
                            ft.TextSpan(
                                self.user_data.get('email', "Не указано"),
                                style=ft.TextStyle(
                                    weight=ft.FontWeight.NORMAL,
                                    color=ft.Colors.GREY_400
                                )
                            )
                        ]
                    ),
                    ft.Text(
                        f"{translate("Адрес", self.lang)}\n",
                        weight=ft.FontWeight.BOLD,
                        spans=[
                            ft.TextSpan(
                                self.user_data.get('adress', "Не указано"),
                                style=ft.TextStyle(
                                    weight=ft.FontWeight.NORMAL,
                                    color=ft.Colors.GREY_400
                                )
                            )
                        ]
                    ),
                    ft.Text(
                        f"{translate("Должность", self.lang)}\n",
                        weight=ft.FontWeight.BOLD,
                        spans=[
                            ft.TextSpan(
                                roles.get(self.user_data.get('role'), "Не указано"),
                                style=ft.TextStyle(
                                    weight=ft.FontWeight.NORMAL,
                                    color=ft.Colors.GREY_400
                                )
                            )
                        ]
                    ),
                    ft.FilledButton(
                        translate("Панель администратора", self.lang),
                        visible=True if self.user_data.get('role') == 'admin' else False,
                        on_click=lambda e: self.page.go("/admin"),
                        style=ft.ButtonStyle(
                            shape=ft.RoundedRectangleBorder(5),
                            color="#1f1f1f",
                            bgcolor=ft.Colors.AMBER_ACCENT_400
                        )
                    )
                ], spacing=15, alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.START, width=350),
                expand=True,
                alignment=ft.alignment.center
            )
        ]
