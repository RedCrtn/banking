import requests
from requests.auth import HTTPBasicAuth
from typing import Dict, List, Optional


class ApiClient:
    def __init__(self, base_url: str = "http://127.0.0.1:8000"):
        self.base_url = base_url.rstrip('/')

    def authenticate(self, login: str, password: str) -> Optional[Dict]:
        """Аутентификация пользователя"""
        try:
            response = requests.post(
                f"{self.base_url}/auth",
                auth=HTTPBasicAuth(login, password)
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Authentication failed: {e}")
            return None

    def change_password(self, login: str, current_password: str, new_password: str) -> bool:
        """Смена пароля пользователя"""
        try:
            response = requests.post(
                f"{self.base_url}/change-password",
                auth=HTTPBasicAuth(login, current_password),
                json={"new_password": new_password}
            )
            response.raise_for_status()
            print("Password changed successfully")
            return True
        except requests.exceptions.RequestException as e:
            print(f"Password change failed: {e}")
            return False

    def get_clients(self) -> List[Dict]:
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.get(
                f"{self.base_url}/users/clients",
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")
            return []

    def create_report(self, client_id):
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.post(
                f"{self.base_url}/create_report/{client_id}",
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")
            return []

    def create_user(self, user_data: dict):
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.post(
                f"{self.base_url}/create_user",
                json=user_data
            )
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")
            return False

    def create_document(self, doc_data: dict):
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.post(
                f"{self.base_url}/create_doc",
                json=doc_data
            )
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")
            return False

    def add_client_product(self, data: dict):
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.post(
                f"{self.base_url}/add_client_product",
                json=data
            )
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")
            return False

    def del_client_product(self, data: dict):
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.post(
                f"{self.base_url}/del_client_product",
                json=data
            )
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")
            return False

    def remove_report(self, client_id: int):
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.post(
                f"{self.base_url}/remove_report/{client_id}",
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")

    def get_report(self, client_id):
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.get(
                f"{self.base_url}/get_report/{client_id}",
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")
            return []

    def get_reports(self):
        """Получение списка клиентов (только для администратора)"""
        try:
            response = requests.get(
                f"{self.base_url}/get_all_reports",
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Failed to get clients: {e}")
            return []


    def get_current_user_data(self, login: str, password: str) -> Optional[Dict]:
        """Получение данных текущего пользователя"""
        return self.authenticate(login, password)

    def get_all_products(self) -> List[Dict]:
        """Получение списка всех продуктов (без авторизации)"""
        try:
            response = requests.get(f"{self.base_url}/products")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Failed to get products: {e}")
            return []

    def update_product(self, product_id: int, name: str, description: str) -> bool:
        """Обновление продукта (без авторизации)"""
        try:
            response = requests.put(
                f"{self.base_url}/products/{product_id}",
                json={"name": name, "description": description}
            )
            response.raise_for_status()
            print("Product updated successfully")
            return True
        except requests.exceptions.RequestException as e:
            print(f"Product update failed: {e}")
            return False

