

language = {
    "en": {
        "Назад": "Back",
        "Язык": "Language",
        "Тема": "Theme",
        "Пароль": "Password",
        "Обратная связь": "Feedback",
        "Тёмная": "Dark",
        "Светлая": "Light",
        "Системная": "System",
        "Сменить пароль": "Change Password",
        "Смена пароля": "Password Change",
        "Адрес": "Address",
        "Должность": "Post",
        "Телефон": "Phone number",
        "Предлагаемый продукт": "The proposed product",
        "Оставить": "Leave",
        "Клиенты": "Clients",
        "Продукты": "Products",
        "Отчетность": "Reports",
        "Настройки": "Settings",
        "Личный кабинет": "Personal Account",
        "Профиль": "Profile",
        "Подробнее": "Details",
        "Сформировать отчет": "Generate Report",
        "Оформить договор": "Create Contract",
        "Продолжить": "Continue",
        "Логин": "Login",
        "Старый пароль": "Old Password",
        "Новый пароль": "New Password",
        "Вход": "Sign In",
        "Управление": "Management",
        "Панель администратора": "Admin Panel",
        "Предложить продукт": "Suggest Product",
        "ИТОГО ДОХОДОВ": "TOTAL INCOME",
        "ИТОГО РАСХОДОВ": "TOTAL EXPENSES",
        "Подписать договор": "Sign Contract",
        "Создать нового пользователя": "Create New User",
        "Продукты клиента": "Customer's Products"
    }
}

def translate(key: str, lang: str = "ru") -> str:
    if lang == "ru":
        return key
    return language.get(lang, {}).get(key, key)