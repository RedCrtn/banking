import flet as ft

dark_theme = ft.Theme(
    color_scheme=ft.ColorScheme(
        primary="#424242",
        on_primary="#ebebeb",
    ),
)
light_theme = ft.Theme(
    color_scheme=ft.ColorScheme(
        primary="#d9d9d9",
        on_primary="#000000"
    ),
)