import os
import random

from PIL import Image, ImageDraw, ImageFont

# Загружаем исходное изображение анкеты
image_path = "IMG_0483.PNG"
output_path =  os.path.join(os.environ['USERPROFILE'], 'Desktop', f"ANKETA-{random.randint(1, 99999999)}.png")


def create_doc_not_signet(user_data: dict, signet: bool = False):

    # Создаем объект изображения
    img = Image.open(image_path)
    draw = ImageDraw.Draw(img)

    # Шрифт для текста
    font = ImageFont.truetype("arial.ttf", 12)  # Можно использовать другой шрифт

    # Координаты полей
    coordinates = {
        "fio": (100, 155),
        "date_of_birth": (120, 205),
        "phone_number": (175, 216),
        "address": (100, 350),
        "passport": (520, 190),
    }

    # Заполняем поля
    draw.text(coordinates["fio"], user_data.get('fio'), font=font, fill=(0, 0, 0))
    draw.text(coordinates["phone_number"], user_data.get('phone'), font=font, fill=(0, 0, 0))
    draw.text(coordinates["passport"], user_data.get('passport'), font=font, fill=(0, 0, 0))

    # Сохраняем результат
    img.save(output_path)
    return output_path

def signet_document(user_data: dict):
    path = create_doc_not_signet(user_data, signet=True)

    # Создаем объект изображения
    img = Image.open(path)

    # Загружаем изображение электронной подписи
    signature_path = "podpis.png"
    signature = Image.open(signature_path)

    # Определяем координаты, где будет размещена подпись
    signature_position = (450, 1140)  # Пример координат (x, y)

    # Наложение подписи на основное изображение
    img.paste(signature, signature_position)  # mask=signature для прозрачного фона

    # Сохраняем результат
    img.save(output_path)

