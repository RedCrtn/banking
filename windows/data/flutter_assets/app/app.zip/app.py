import flet as ft
from flet.core.template_route import TemplateRoute

from language import translate
from pages import AccountPage, ClientsPage, ClientPage, AuthPage, ProductsPage, SettingsPage, ReportPage, \
    ReportListPage, AdminPage
from storage import get_theme, get_lang
from themes import light_theme, dark_theme


class Router:
    def __init__(
            self,
            page: ft.Page,
    ):
        self.page = page

    def pages(self) -> ft.View:
        router = TemplateRoute(self.page.route)

        if router.match('/account'):
            return AccountPage(self.page)
        if router.match('/clients'):
            return ClientsPage(self.page)
        if router.match('/client'):
            return ClientPage(self.page)
        if router.match('/products'):
            return ProductsPage(self.page)
        if router.match('/settings'):
            return SettingsPage(self.page)
        if router.match('/report'):
            return ReportPage(self.page)
        if router.match('/reports'):
            return ReportListPage(self.page)
        if router.match('/admin'):
            return AdminPage(self.page)
        else:
            return AuthPage(self.page)

    async def change_route(self, e) -> None:

        self.page.views.clear()
        self.page.views.append(
            self.pages()
        )
        self.page.update()

async def main_app(page: ft.Page):
    page.title = "Flora Manger"

    router = Router(page)
    page.on_route_change = router.change_route

    theme_mode = get_theme()
    page.theme_mode = theme_mode
    page.theme = light_theme
    if theme_mode == "light":
        page.theme = light_theme
    elif theme_mode == "dark":
        page.theme = dark_theme

    page.go('/auth')

if __name__ == "__main__":
    import sys
    import io

    if sys.stdout.encoding != 'UTF-8':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    ft.app(main_app)